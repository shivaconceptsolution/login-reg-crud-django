from django.db import models

class Student(models.Model):
	rno= models.IntegerField()
	sname=models.CharField(max_length=50)
	branch=models.CharField(max_length=20)
	fees = models.FloatField()
	def __str__(self):
		return "rno is "+str(self.rno)+ " sname is "+self.sname + " branch is "+self.branch+ "fees is "+str(self.fees)

class Course(models.Model):
	courseid=models.IntegerField()
	coursename= models.CharField(max_length=50)
	coursefees=models.CharField(max_length=20)
	def __str__(self):
		return "courseid "+str(self.courseid) + " coursename is "+str(self.coursename) + " fees is " + str(self.coursefees)

class Reg(models.Model):
	uname= models.CharField(max_length=20)
	pwd=models.CharField(max_length=10)
	email=models.CharField(max_length=20)
	mobile = models.CharField(max_length=12)
	def __str__(self):
		return "rno is "+str(self.uname)+ " password is "+self.pwd + " emailid is "+self.email+ "mobile no  is "+str(self.mobile)
