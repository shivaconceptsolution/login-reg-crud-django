from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Student,Course,Reg

def login(request):
	if request.method=="POST":
		r = Reg.objects.filter(uname=request.POST["txtuser"],pwd=request.POST["txtpass"])
		if r.count()>0:
		  return redirect('/dbapp/index')
		else:
		  return HttpResponse("Invalid Userid and password")  
	return render(request,"dbapp/login.html")	

def reg(request):
	if request.method=="POST":
		r = Reg(uname=request.POST["txtuser"],pwd=request.POST["txtpass"],email=request.POST["txtemail"],mobile=request.POST["txtmobile"])
		r.save()
		return redirect('login')
	return render(request,"dbapp/reg.html")	

def index(request):
	if request.method=="POST":
		obj = Course(courseid=request.POST["txtrno"],coursename=request.POST["txtsname"],coursefees=request.POST["txtbranch"])
		obj.save()
		return render(request,"dbapp/index.html",{"res":"data inserted successfully"})

	return render(request,"dbapp/index.html")


def course(request):
	res = Course.objects.all()
	return render(request,"dbapp/course.html",{'data':res})

def editrec(request):
	if request.method=="POST":
		e=request.POST["tcid"]
		m=request.POST["tcname"]
		f=request.POST["tfee"]
		s = Course.objects.get(pk=request.POST["txtid"])
		s.courseid=e
		s.coursename=m
		s.coursefees=f
		s.save()
		return redirect('course')
	else:
		res = Course.objects.get(pk=request.GET["q"])
		return render(request,"dbapp/editrec.html",{'data':res})
   

def deleterec(request):
	if request.method=="POST":
	 res = Course.objects.get(pk=request.POST["txtid"])
	 res.delete()
	 return redirect('course')
	else:
	  res = Course.objects.get(pk=request.GET["q"])
	  return render(request,"dbapp/deleterec.html",{'data':res}) 


