from django.urls import path
from . import views

urlpatterns = [
path('',views.login,name='login'),
path('reg',views.reg,name='reg'),
path('login',views.login,name='login'),
path('index',views.index,name='index'),
path('course',views.course,name='course'),
path('editrec',views.editrec,name='editrec'),
path('deleterec',views.deleterec,name='deleterec'),

]